**Week 13 Meeting**

1) Discussed where the assignment building was that, as well as reconvening what different people's code did
2) Code consolidation conducted
3) Checked on progress in documentation process and assigned roles to complete it
4) Continued work collaboratively on codebase, making key design decisions