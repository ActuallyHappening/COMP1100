# Week 2 Meeting:

## Agenda
- Challenge chosen: selecting course requirements
- Discussed:
  - Questions to be chosen to be asked (1 open, 1 closed)
  - Only ask the open OR closed question to someone
  - Record their answer with a voice recording app (e.g. voice memos)
  - Transcribe the interview with a transcription app or manually
- Next steps:
  - Reconvene on teams @11:00 Monday 11 on teams for 1 hour to discuss results and put in report
