**Week 9 Meeting**

### Part 1
1) Went through assessment items to ensure that all aspects had been appropiately filled out
2) Noted any aspects that should be changed over the next 12 hours to polish solution

### Part 2
1) Discussed what the UI of the developed website should take to best form a solution
2) Decided on what features should be focused on in creating an MVP
3) Assigned roles to building the website based on language
    - Patrick & Rafael: HTML
    - Himanshu: CSS/Styling
    - Liam & Caleb: JS/Vue/Database