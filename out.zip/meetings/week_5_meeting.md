### Week 5 Agenda

**Item 1**
Review interviews
- Interviews are so far going well, most people will be finishing up interviews over the next coming days. 

**Item 2**
Discuss learning cards
- Structure discussed and can be found in learning_cards.md.

**Item 3**
Make learning  cards
- learning cards made.

**End Result**
- Finish interviews
- For every learning card, everyone is to place in 1 piece of evidence (where possible) that they have collected from interviews. 