**week 11 meetings**

1) Briefly discussed what needed to be done for assessment items in iteration three. 
2) Full development of figma confirmed that will exactly mimic the MVP. 

See Patricks design for the structure of both the figma and MVP. [Patrick's design](https://wireframe.cc/kqN2t8)

See Liams design for the figma for the most accurate representation of the MVP. [Figma](https://www.figma.com/design/Yb9IH8Shsnvece29JBb0xT/Figma--V2?node-id=0-1&t=lfZCIs3N9kiiBgM5-1)

Information is being finalised and inserted into the surreal DB by Caleb's design. [Surreal DB](app.surrealdb.com/connections/create) is being used as our DB manager

Figma was agreed to be completed this friday by Liam B, to which the group will immediately begin final iteration interviews so Rafael C can fully implement the remaining iteration three requirements.