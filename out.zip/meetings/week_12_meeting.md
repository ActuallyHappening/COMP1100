**Week 12 Meeting**

1) Reviewed where we were up to on the website
2) Worked on pitch for week 13
- 1-minute elevator pitch: Liam Bienkowski
- Problems: Rafael Chase
- Project: Patrick Elgey
- Solution: Caleb Yates
3) discussed UI