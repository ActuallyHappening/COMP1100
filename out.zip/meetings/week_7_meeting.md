### Agenda item 1
Discussed where to go from the end of iteration 1 to get to iteration 2

### Agenda item 2
Discussed why we discarded certain hypothesis and how we could refine

### Agenda item 3
Progressed on making new hypotheses and test cards for value propositions to be tested over the next week

### Agenda item 4
Discussed next week's agenda: refer to answers to interviews and then make hypnotheses for the MVP. 