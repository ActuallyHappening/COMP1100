**Week 10 Meeting**

1) Went through assignment items for iteration 3 to determine what needs to be done
2) Began to dissect how to best approach developing an MVP
- Key focus feature: course plan
    - Other features can come later if deemed neseccary
    - [Patrick's design](https://wireframe.cc/kqN2t8) will be used as an example and developed into a [Figma](https://www.figma.com/design/Yb9IH8Shsnvece29JBb0xT/Figma--V2?node-id=0-1&t=lfZCIs3N9kiiBgM5-1)
    - [Surreal DB](app.surrealdb.com/connections/create) is being used as our DB manager
- Decided on who is doing what over the next couple of weeks
    - Caleb: Working on code/implementation of solution
    - Liam: Working on filling out DB with items + Making new Figma to reflect iteration 2
    - Patrick + Rafael: Working on HTML frontend of the course planning page
    - Himanshu: Working on CSS to complement the HTML frontend