**Agenda:**
Item 1: View Blackboard page to understand what was required for submission

Item 2: Work through meetings gathered so far and take a stance for learning cards

Item 3: Finalise key MVP features for prototype

Item 4: Assign tasks to individuals to work through over the next week

Next steps: Work through assigned tasks found on GitHub Projects