<script setup lang="ts">
import State from "./components/State.vue";
</script>

<template>
	<main>
		<State>
			<RouterView />
		</State>
	</main>
</template>

<style scoped></style>
