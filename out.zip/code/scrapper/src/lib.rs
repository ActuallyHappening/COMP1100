pub mod prelude {
	pub use ystd::prelude::*;
	pub use ystd::url::Url;
}

pub mod db;
pub mod scraper;
