# COMP1100
## UQ St Lucia COMP1100 Team 10
### Members
- Patrick Elgey
    - 49637870
    - @TNTreee
    - p.elgey@student.uq.edu.au

- Rafael Chase
    - 49618459
    - Rafael-Chase
    - rafael.chase@student.uq.edu.au

- Liam Bienkowski
    - 49898953
    - @liamb-a
    - l.bienkowski@student.uq.edu.au

- Himanshu
   - 49661428
   - codingaddict-debug
   - himanshu@student.uq.edu.au

- Caleb Yates
    - 49886351
    - actuallyhappening
    - caleb.yates@student.uq.edu.au
