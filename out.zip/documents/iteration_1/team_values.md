# Team values
1. **Trust**: I trust that someone will write a description here
2. **Communication**: We should communicate about writing description for this
3. **Leadership**: I will delegate someone to write a description here
4. **Grit/hard working**: Someone will work hard at a description here
5. **Don't be someone who is annoying and silly**: Self explanatory
6. **Inclusion**: Everyone is welcome to write a description here
