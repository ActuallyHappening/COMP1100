### MVP Interview 1
*Interview can be found [here](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=/teams/Section_7560_62502/Shared%20Documents/Mon_9am_Team_10/liam_bienkowski_audio_recordings/iteration_2/liam_bienkowski_2025-09-22_4.mp3).*

Liam: *Jonathan Jesuthesan, do you agree to have this audio recorded?* 

Jonathan: 
>Yeah. 

Liam: *So just a few questions on the prototype that you just saw. So what did you like about the design?* 

Jonathan: 
>Yeah, I liked, like, the layout and everything, very simple, like easy to click things. Like, yeah, I like the design of it overall. And also, um, it's like, like you click on something, it takes you to another page, it doesn't like try and fit it all into one page. So I liked, it was very well, like the easy on the eyes. Not too much on one page. 

Liam: *Yep, and what did you not like about the design?* 

Jonathan: 
>Yeah. The one thing is that little arrow thing is like clicking on the bubble versus clicking on the arrow. It was a little bit klunky, I think, just 'cause I couldn't work out whether there was two buttons there or one button. So, like, that could maybe be a bit clearer. Oh, also like, well, I don't know if it's like a thing that can really be fixed. But like the titles of the themes. Like viewing the course plane and whatever. Like, it's probably something you just get used to. Like, they're naming of the different pages. 

Liam: *So with those titles, then, like, what did you not find intuitive about it?* 

Jonathan: 
>Yeah, I think it's just because it's different to what I'm used to. Like the very 1st task, which was like, um, find out which subject you failed. I was looking for like course results or something, right? But that was within the courses you already do. So, um, like it does make sense now, but I guess at first it just wasn't what I was expecting. But once I clicked on each thing at least once, it was fairly intuitive. Like, it made sense after the fact. So I guess I guess it's like there's not really any really comment on that. I just thought I'd say that. Yeah, yeah. 

Liam: *So, like, is there some pages at UQ already that you would expect to be, like, that have forms your opinion on what they should be called, that you could quote?* 

Jonathan: 
>Yeah, maybe I was thinking mySI-Net. Like, that's the one I'm thinking of, like, what I've expected to be called. Like it's got, um, like you know, financials page. It's like an enrolment page. Like that's initially where my mind goes. But like, in that sense as well. when I first opened those websites, it was not intuitive at all, right? The only way I found out where everything was is trial and error, right? I clicked on every single button until I found out where everything was. So I wouldn't say that's necessarily intuitive, but it's just that's already been set in my mind. So that's probably where my mindset was sort of going. Not necessarily that it's intuitive or not, just the fact that I hadn't seen it before. 

Liam: *Yeah. And were you able to complete all the tasks that were set for you?* 

Jonathan: 
>Yes, I was. 

Liam: *And could you like describe that experience?* 

Jonathan: 
>Yeah. So I think the very first task, or like apart from logging in, like the very first task, the very first task. was probably the hardest, just because I did go through a bit of trial and error, like clicking on all the different things. But then once I found the first one, which one I failed, then it was fairly easy to do all the other tasks because I'd already by then, just by nature of it, I clicked on every wrong button before I clicked on the right one. So I figured out where everything was. And it was intuitive enough that I could remember it easily. So, I found most, I think most of the tasks were pretty easy to complete. Like bar that 1st task, which I think was more user error than it was, like, designer. Oh, yeah. 

Liam: *And did you have any struggles finding any other information?* 

Jonathan: 
>Yeah, I think maybe when like I click on and it takes me to the subpage, maybe a brief description of what the subpage is because it said like courses or something, right? But I think courses could probably mean a few different things. Like, is this a enrolling in course? Passed courses? Is this like, managing, like, timetable or something for those courses? Like, maybe just like a small thing on that. Like, might be a bit helpful, like, in terms of information. Just because it's really clear that what page I'm actually going to. Yeah. Yeah. 

Liam: *And so was there anything in like this form of solution that you feel like was glaringly like missing from it?* 

Jonathan: 
>Um, I don't think necessarily. Like, obviously it's a prototype. But I think... Yeah, I think it covered most bases. I think maybe, like, it was still, there was a little bit full on at points, I think, like, maybe a bit more, like, like, just like description, like a bit more, a few more words just describing, like, what is this page useful? Like a little blurb somewhere. I don't know exactly where that fit in. Because you don't want to just chuck it on the page, right? It's a bit like clunky. But like, I feel like fitting that in some way, like being like, this is where you can manage, you know, course enrolments. This is where you can manage your past grades or something like, just a little thing of like, sort of like the video game, like tutorial kind of thing. Like, like a pop-up, maybe, I don't know, if that's like where exactly that fits in. But that would probably be helpful just to be like, okay, that's what I use this subsection for. Okay, that's what I use this subsection. 

Liam: *Yeah, and so like on that then, would you refer a system where it's just like always present? like a little description on every single page? Or would you like instead a tutorial on 1st boot up that walks you through how it works and then leaves you to your own devices?* 

Jonathan: 
>I think, I think probably, I think... I think probably, like, the 1st, like, um, like maybe the 1st time a tutorial. But, like, I don't know if you, like, go like an info button kind of thing. Like having something like that, because it's like, you don't want to see it all the time, because it would really get annoying and get on your nerves. Like, opening every time. There be a pop-up or every time there's like a big chunk of text. But it's like, if you ever forgot, or if it's your 1st time, you'd be like, okay, I'm gonna click the info. Like, that kind of thing? Um, that's probably, I'd say, the best way to go around it. But I think a tutorial 1st time around could also be helpful. But yeah, I wouldn't want it always there. 

Liam: *All right, well, thank you very much, Jono.* 

Jonathan: 
>That's all right.