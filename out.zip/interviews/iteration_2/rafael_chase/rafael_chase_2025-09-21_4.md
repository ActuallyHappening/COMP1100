Rafael: Is it okay if I record you? 

Ruby: Yeah.

Rafael: Thank you, okay, I'm going to be taking you through the prototype for my group's innovation on course, planning and requirements. Right. So right here is the starting page. You just enter your student number.

This is a bit like that this stage might be removed, so please keep that in mind. Like, it's just to link it personally, but we don't know if that'll actually make the final cut yet. So let's just say this is your number, you click enter, right?

And it will personalise, like it'll be personalised when it welcomes you. So in this case, welcome Rafael, they used my name for it because you'll see in a second. So the whole idea is that this keeps track of all your courses, right?

So we've got these four areas. We've got view your course classes, view major, minor options, view your plans, and view class reviews. Now, so the only ones linked right now are these three. View your core classes or course classes if I were to click this, then we can see which ones I've done, right? 

So I've passed these ones with a six, and I apparently failed that one with a one. In progress and or failed is these ones. So these are the courses, the exact causes of doing right now, except for that, right? So they're you know, incomplete, right? So they don't have a school. And then upcoming ones that I've selected are like this one here and if I click this down here, it shows me the prerequisites and the commencement start date. So this one is only offered in semester two. 

Right? So that's that first page, after I just go back to the home button right there. I can view my major and minor options for the Bachelor of Math, which is half of my degree. I've got a potential in pure mathematics, and it shows me like the next few courses doing that, right? So it's obviously applicable to anyone's degree. That one's not linked yet. and it shows you which one like you've selected. So in this case, the major selected artificial intelligence, just with the tick there.

And then these drop downs will have like the courses you have to do, kind of like how it exists now in like the programs and courses screen. You know that one? 

Ruby: Yeah, I know that one. 

Rafael: Yeah. It's very similar to that. 

And then we can view our plans that we like that you have saved. So in the saved plan one, we've got all this, right? So this is just like a potential plan, right? Spit up to the semesters by year and then you can select which courses you want to choose, where and then it's just going to tell you what the programs are for all, then what you have to do. 

And it'll highlight red if it can't be done. Like it's an incompatible choice. It'll be green if of course, you can do it or you are doing it. Right? So with this in mind, oh, sorry, and this is in the future, what will be here is essentially just like the little review forum for people. So if you just, if you like a course, you just quickly type up, yeah, I like this course and it might show up and people will see that you like the course. 

If you didn't like it, then that might show up. If you've got questions, kind of like Ed SEM, you ask the questions, somebody might answer it if they're feeling very nice. But that's a work of progress, so with this in mind, is there anything that you think is lacking or do you think there could be any obvious improvements? 

Like, do you like the layout of it? Anything helps? 

Ruby: I like the layout. I like the layout. I think that. I really like it. I think it's good. I think having the plan is very useful. I think having the ability to save plans is very useful.

I don't think I'd change it. I do think that maybe being able for it to generate a plan for you would be good instead of, you having do it yourself, maybe if the thing could program it for you, kind of like how it does a your timetable, I think that would be a good way to start, or it could, you know, like how the timetable works, where it says, give me a draft plan and it kind of gives you something and then you can go in and edit it yourself kind of thing. 

Rafael: I think that's quite complicated about what, like, we could do instead is just have, like, some mock plans, like, as in, like the UQ plan obviously leaves a lot of free space, so it could just make recommended plans that we've calculated, just give it to people. Of course, it's a lot of work, but do you think that would, like if you just had one or two? 

Ruby: But how would a mock plan like a mock plan how does it make it more like personalised if you can't get more personalised through the UQ system and then you can't just generate a plan for itself? Like, how do you find a middle ground between that? It's not really, you can’t really do that...

Rafael: As I said, it's a work in progress, so...

Rafael: I accept that. That is a good point that I hadn't thought of. I appreciate your input. Is there anything else that you anything else that you think like could be? 

Ruby: No, I think it's great. You like it? Yeah, I like it. 

Rafael: Would you use it? 

Ruby: Yeah, I would.

Rafael: Do you think that this makes it more complicated because we've added yet another website of the many websites to use planning of course? Because this isn't isn't like a…

Ruby: I think if maybe you could like make it a part of timetabling, then that would solve that problem. 

Rafael: Yeah, because what this isn't and this is very important, it doesn't select the courses for you. You still have to go into my SI-net and choose the courses. This just gives you the template. You have to put it in the timetable. Okay, so do you think that this would be helpful provided that students know about it and it's like actively a part of the process instead of just like a sort of like you could grade calculator, right? Like I didn't know about it until somebody told me. Right? Like yeah, like how it…

Ruby: I think it's good. Awesome. I would use it. 

Rafael: Great. Thank you.
