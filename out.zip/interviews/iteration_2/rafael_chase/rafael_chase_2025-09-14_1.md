Rafael: Hello, is it okay if I record you? 

Liam Mcbride: Absolutely, it's okay if you report me yes 

You: Okay, thank you. Could you please take your name and your degree, please? 

Liam Mcbride: My name is Liam Jack McBride currently studying law honours and bachelor science at UQ with an intention of doing an extended major in psychology 

Rafael: Thank you. So when you choose when you're choosing your courses, do you try to take courses with your friends where possible? 

Liam Mcbride: Absolutely in fact I've got stat 1301 right now that I specifically chose so I could be with a friend from high school 

Rafael: Right, did you have to complete the stats course anyway? 

Liam Mcbride: I didn't have to complete it at school, but not that one specifically so yeah 

Rafael: Okay, so that decision was purely made out of wanting to do with friends?

Liam Mcbride: Absolutely I think friends are important aspect for learning and definitely make it a lot more enjoyable 

Rafael: Right is that the only time you've done this or have you done this previously with other courses? Are doing it right now with other courses? 

Liam Mcbride: To be honest, this is the only opportunity I really had to do it for the courses that wasn't like fundamentally different so what degrees I was doing But I'm sure if you got the opportunity, I'll try and do it again 

Rafael: Okay so would you say this is a significant factor in choosing for your courses? 

Liam Mcbride: Yeah, I think it's difficult 

Rafael: Right and is there something you go into with that mindset like you go into it with the mind that you're gonna do all the courses with your friends or do you select your courses and see if there's any mutual mutual courses and then sort of arrange it? 

Liam Mcbride: I think obviously the grey I know with mine not so much of the first courses but there will be a bit of variability to be your freedom to choose when you do specific courses or out of a list of courses which ones to do so when doing that I'm genuinely trying to consult my close friends seeing which ones they're doing Keep that in the back of my mind is given the option between two choices again. I'm also factoring and just wouldn't be helpful to myself like a course while I was definitely considering my friends. It was definitely more challenging than the other one and more beneficial so that was also probably the motivation. 

Rafael: Okay, did you know that my SI-net has a built-in way to share timetables? 

Liam Mcbride: I've heard about it, but to be honest, I don't know much about it. I know I don't use it. 

Rafael: you just don't use it? or was it just like when you say that you know of it did you always know of it or was it a friend that told you? 

Liam Mcbride I had a friend that told me 

Rafael: Do you think it would be more beneficial if there was a way you could better collaborate prior to selecting courses or do you already confer with friends prior to selecting courses? 

Liam Mcbride: Yeah, probably would be good in the sense that I know was like my close friends but there's some friends who that's close to where I know they agree but I don't actually notice the specific course is that we have some mobile app Yeah, might be nice to have a system in place for that.

Rafael: Okay what about course planning? Have you ever planned your courses for the upcoming term? You know like how many semesters ahead have you planned or is it not at all? 

Liam Mcbride: It's a good question. It's generally semester straight at a time for me I think. Just looking at the courses I need to have completed

Rafael: Okay. Do you worry about planning? Like do you think planning too far in advance isn't useful or do you find that your degree is very rigid so you don't need to plan? 

Liam Mcbride: I think my degree is quite rigid at the moment, especially my law components So I don't really feel a need to plan too heavily 

Rafael: Right and when you're collaborating with friends, if they do do or do you find it to be a lot easier since it's a very rigid structure 

Liam Mcbride: Yes 

Rafael: Okay, and is that something that you're always doing? You're always doing the same things as your friends? 

Liam Mcbride: Yeah, pretty much so it comes to law, if you’re starting first year together most of it you'll be doing the same courses at least in my experience of the first year. So people you know if you start with them for a while.

Rafael: And would you say you've ever planned more than two semesters ahead or is it genuinely something you've just never done? 

Liam Mcbride
Well I’ve consulted the degree planner on the UQ website but that as a active decision of two semesters ahead I'm not active in my planning if make sense 

rafael: Right so you did mention that you use the course plan so whenever you do you know have the sudden curiosity to check what you're doing or have a bit of a think about it. Do you use the UQ course planner, do you talk with friends? How do you do it? 

Liam Mcbride: Yeah I just use the UQ course planner. Just Yeah, that's it 

Rafael: Would you like to see your system? My previous participants of a course can leave a notes of a summary of the course so you know like add step right? Imagine that but before you start the course you get to talk with people I've already completed it. maybe cool staff tutors do you think that would be useful? 

Liam Mcbride: Yeah, I think they'll be very useful

Rafael: Is that a system that you would use a lot do you think? 

Liam Mcbride: I think so especially when it comes to preparing for assessments and courses I know I have to do or choosing between elective courses yet 

Rafael: Yeah, do you find it useful right now to talk to students who have already completed these courses? If you do you know no people who have. 

Liam Mcbride: Yeah, I do and I've done that for my sci 1000 course. I found a useful so far but again sometimes there's a problem with accessing people knowing to courses that you're about to do 

Rafael: Would you personally participate in that? So would you find yourself talking to you know people who want to know about a corset you've completed? 

Liam Mcbride: Certainly on a personal level, whether or not I'd submit a response or an inquiry maybe if I was asked to by a lecturer or a tutorial leader like a teacher. Of my own volition probably not, no. Maybe with an incentive. 

Rafael: Okay and would you prefer a system with core staff for president these Forbes or not present? So would you rather have a solely student based response or tutor based or a bit of both? 

Liam Mcbride: I think an integrated one with both would be good.

Rafael: Okay, thank you Liam for your time.

Liam Mcbride: Thank you, Rafael 
