Rafael: So firstly, do you mind if I record you?

Hongkai: No. I no, I don't. 

Rafael: Okay, thank you. Do you try to take courses with your friends where possible? 

Hongkai: Oh. Well, I'm actually. Like, I didn’t live in Queensland originally, so I didn't actually have any friends here before I moved… 

Rafael: Ah right

Hongkai: So, I kind of took whatever course that was what I was supposed to do. I didn't really consider that part. 

Rafael: Right. Do you think, like, in the future, that's something you'd prefer to do? 

Hongkai: Maybe, yeah. Yeah. So I would be like, I'll be asking around my friends like, well, what they’re taking? Maybe I'll put that into consideration. 

Rafael: Right, so hypothetically, in the future with these hypothetical friends of yours. Do you think you would, like it would be a significant factor in actually choosing your course, or do you think you'd just go with the flow?

Hongkai: Probably not a significant factor, but it's just something I will look out for. 

Rafael: Yeah, right. It's like you are always aware of it. 

Hongkai: Yeah. I'll still follow the planner they give us. 

Rafael: Yeah, yeah. And then like try to pair with friends after you've already chosen them?

Hongkai: Like, especially the timetabling rather than course selection.

Rafael: Do you think it would be more beneficial if there was a better way to actually collaborate when you're choosing courses? 

Hongkai: Um, collaborate when choosing, like talking to other people while choosing courses. Yeah.. that’s interesting. Um. Maybe, like, if you if you had a couple, like, new first year students coming together, they might, none of them might like know what they're doing, right? But, if you did have assistance, like from someone who actually knows, then like choosing courses together, like especially like, if you were in person, like, that would be pretty helpful. 

Rafael: Yeah, okay. What about, like, course planning? How many terms ahead have you planned? 

Hongkai: Oh, um, since I'm following the the course plan for my degree, uh, like to the T, I kind of just it's basically all set up for four years. 

Rafael: Yours is quite rigid. 

Hongkai: yeah

Rafael: Right, okay. 

Hongkai: And since I don't have that many, like electives, I can do, I don't really have any options to move around.

Rafael: Right, so you would say that you don't really have to plan an advance, then. So is that something you don't stress about then? Like, it's just just done for you, right? 

Hongkai: yeah

Rafael: All right, let's say hypothetically. Hypothetically. It wasn't so rigid, do you think you would find yourself planning ahead, knowing exactly what you're going to do or would you just choose it on a whim? 

Hongkai: I I'll probably still sit down and find all four years in, like, one sitting and then just get it over with, but it'll definitely be more difficult, because if you didn't if the plan wasn't, like, as rigid as the one I got, obviously, I had to put in, like all those. I had to consider all the factors, such as like, our prerequisition. Like, like a semester offerings and stuff like that. And that can be a bit of a hassle. 

Rafael: Okay. Would you like to see a system where previous participants of a course can, like, leave a note of summaries? Like, right now when you've got the course plan on you're choosing a course, it just gives you like a brief overview. Sometimes it's like two sentences, sometimes it's like a full paragraph. But it can always be very unclear as to what is actually in the course. So like, imagine like Ed Stem, right? Like you ask a question and then somebody who's done the course before answers to the question. Like, do you think that would be useful? 

Hongkai: It would be very useful. Like, it gives students a good expectation of what to expect, right? 

Rafael: Yeah, yeah. All right, so you would find yourself reading short opinions of courses, right? So it's something like, would you take that into consideration when you take a course? 

Hongkai: Yes, certainly. Like, if there was, like, a reading system or something, that would be pretty good. Like, if you, if students could rate a course, maybe like, different aspects, like, how interesting it was or, like, how difficult it was, right? That would definitely be taken into consideration choosing courses. 

Rafael: And would you ever find yourself actively participating in that as somebody helping other students? At the very least, just, you know, posting one thing, right? It's like, oh, I found this course, you know, to be fun. And you’re just, like, done. Like that's, you've done the part. 

Hongkai: Maybe. Yeah, okay. Otherwise, like, you wouldn't really do it. 

Rafael: Yeah. That's okay. Would you prefer a system where core staff are present in these forums? Would you like to talk to course staff or just students or like a bit of both? 

Hongkai: Um.. I feel like sometimes core staff probably have a bit of a skewed view on a course, because obviously not from the student's perspective, right? Yeah. So I think it's good to have a boat, but I think I would personally, I just see more like a student's side.

Rafael: Okay. Thank you.
