Rafael: Is it okay if I record you? 

Hugo: Yeah, of course. 

Rafael: Thank you. 

Rafael: Okay, so I'm gonna be taking you through my group's project for comp 1100, which is a software innovation course. So what we've decided to tackle is course planning and choosing courses to make it easier for students to actually go through the process, becauseause right now, as I'm sure you know, it's very, very messy, there's a lot of different things. So we called it UQ plan it for now. 

The name is definitely a work in progress. And so you basically just start by entering your student number, so this is so we can link it to like your MaySI account, basically. So it pulls you detail what degree you're doing, you know, what causes you have and haven't done, like information like that. 

So you know, say this is your number, you enter in, and bing. So this is like the main homes screen.. So in this case, you'll welcome Rafael. 

That's my name. So this is like the template was my degree, basically. So we've got V call courses, major minor options, your plans, and course reviews. 

So and then we've got like notifications here. So it, you know tells you if you haven't chosen, you know, like a major or like some courses or something, you know for whatever.. And then right here we've got my courses. 

So if I just go here, then we can see what I've done. So in this case, I've got INFS, math, math, and CSSE. I've got a six and three of them, and a one in CSSE apparently. 

So, you know, but it comes up as, you know, like that you failed it in red, right, when you do. And you know, in the 6s, it's green, that you pass, tick, and then the warning if you fail. So the courses that you're currently doing is that in progress is, you know, all these courses. and then upcoming. 

So courses that are upcoming in my degree. So if I just click down on here, we'll see the pre-requisites for the course, and the earliest commencement date. So in this case, this cause, comma 2048, can only be taken in semester 2.

So the early I can take it that is semester 2, 2026. Right. And it's not implemented for the rest of these courses yet, but, you know, that's like the general premise of what will be there. 

All right. So that's this screen, quite basic, so we just go back to home here, and we can view the major minor options for each course. So obviously, this right now is personalised towards my degree, but, you know, obviously applicable to all students.

So if I, you know, check like my major minor, like, you know, first thing, like for pure mathematics, for example, Math 2001 or mathath 2901, and then math 2301, those are all courses that you have to do for that, so it's just like outlining what you have to do, right? Okay. And then for, like artificial intelligence, say in the computer science component of the degree, that's not linked. 

But it basically shows you the course that you have to do it. Like as opposed to this and, you know, in an ideal world, as I showed you before, it would show it would show like the prerequisites and stuff like that. So if we just go back to home and we can now review my plans. 

So these are like plans that we've made so you can create a new plan. with, you know, it's like drag and drop, pretty simple. It's just boost stuff around. Anyway, so we go back and we can check, like a saved plan, and so we see the courses that we have here. 

If I, like undo and open up the card, we can see you know, the things during the course and like prerequisites for it, stuff like that. As you can see, it's prototype so we don't have everything quite ironed out yet, but this is the journey process and you can plan for a few semesters ahead. Okay. 

Right? And you can save a plan, make new ones, very simple premise, and then, like viewing class reviews, you can search for a course. So in this case, if I click this, we go INFS 1200 research and we will see feedback for it if I want to leave a comment, just enter a comment. Send, and bang and, it does it, and other students can see that.

Like, you can sort it most recent, you, whatever. 

So that's like the general premise of the reviews. Like, you just leave a comment, that's it, people can see what people like about a course. A system like this does already exist in a similar capacity, but not many students know about it, and we think it'd be very helpful, so we're incorporating it here. 

Okay. So that's the general premise of it, you click the exit button here and it's texted you straight back to the beginning. So if it's okay, I'd like to ask you if there's any feedback that you have, like, what do you like about it? 

What do you not like? What do you think we can do better? Anything else? 

Hugo: Okay. Alright, um, I love the effective format, I think it's, um. It's simple and it's easy to navigate. I'd like how kind of all the options, all the abilities of the app kind of link into helping me plan my semesters. I really like the future planning in particular because I've struggled a lot especially online with finding my future courses and figuring out what I'm actually going to be doing as the years progress. I also do think that the ability to see the prerequisites is helpful. However, with the course classes, I think there needs to be a bit more explanation behind the, um completed classes and then possibly a better format for how to display the upcoming and available classes for the future. 

Rafael: Okay, so, like, would you say that here in, like, the planning, where you're just like, checking out courses is ineffective, or do you mean more so in, like the actual plan? 

Hugo: I don't think it's ineffective, but I think there's probably a more visual way that you could do it. 

Rafael: Yeah, and like, in what way would you say? Like, what's not working?

Hugo: Maybe it's just a separate screen for each of the individual things. just a bit larger... 

Rafael: Okay, yeah. 

Hugo: And easier to, maybe with some details as well. Maybe, for instance, with your completed classes, it might give you a rundown of each assessment in the marks you've gotten that and any feedback, possibly, if that's available, but I'm not sure about that. 

Rafael: Okay, no, thank you. Is there anything else that you think? 

Hugo: Um, not. entirely. I think every. I like all the other, um.. added features of the app. I think it's gonna be really helpful for planning, because as things currently stand, I find it incredibly difficult to actually navigate through other the UQ websites and mySI, and actually planning on my courses. So I like that this is all in one place to help me put it all together, and so I' better understanding of what I'm actually doing with my degree. 

Rafael: Okay. And would you personally use this? 

Hugo: Oh, absolutely, I would. 

Rafael: So do you think, um, like, one last thing when it comes to like course planning, so right now, you obviously have to have a lot of tabs open. It's not a very low-grade system. Do you think that this only adds to the chaos?

Hugo: No, no, I think it completely removes the chaos. I feel like, I would still, of course, have some tabs open with the UQ information and whatnot, but my computer will be running a lot faster with just this and maybe one or two tabs at most. So compared to three screens of 30 UQ related tabs.

Rafael: kay. Is there anything else or…? 

Hugo: No, I think that's all good. I think everything else is, um, pretty solid. 

Rafael: Alright, thank you. 

Hugo: Awesome.
