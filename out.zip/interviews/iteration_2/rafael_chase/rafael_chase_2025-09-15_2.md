Rafael: Could you please state your name and degree? 

Ruby: Ruby Chase PPE. 

Rafael: What's PPE?

Ruby: Politics, phosophy, Economics. 

Rafael: Okay, thank you. Is it okay if I record you?

Ruby: Yes. 

Rafael: Okay. So to start things off, do you try to take courses with your friends where possible?

Ruby: Where possible, like, I’ll sometimes do it, yeah.

Rafael: Right. Is this, like, a significant factor in choosing field courses or is it something that you try to do after selecting them?

Ruby: Oh, it's not significant. Usually after. If I have an elective course within my major, then I might tailor it to a person or try and convince a person to do it with me.

Rafael: Right. So like, how often do you take courses with friends? 

Ruby: Not at all.

Rafael: No? Okay. Did you know that my SI -Net has a built-in way to see your friends' timetables? 

Ruby: No.

Rafael: Yeah. Is that because, like, it's just not easy to find? Like, it's just not intuitive or?

Ruby: Well, no, it’s just that my SI-net sucks. 

Rafael: Wow okay thank you. All right, so have you planned for your courses in the upcoming terms?

Ruby: Yes. 

Rafael: Right, how far ahead you off plan? 

Ruby: Until I've graduated. 

Rafael: Right, so you've got like a very rigid plan for until graduation. 

Ruby: Yeah, I had to in order to make sure I met like the requirements. 

Rafael: Right, okay. Do you worry about that at all?

Ruby: Yeah, sometimes. 

Rafael: Right. What about when you were doing it? Were you worrying about it? 

Ruby: Yes. 

Rafael: Okay, was it part of the process like, was it stress induced? Is that why you did it? Because it's just such a terrible system. Like, you didn't know what to do or? 

Ruby: No, I actually put it together because I wanted, um permission to switch into PPE and to get to be told that this plan would mean that I would graduate at a certain time. 

Rafael: Right, okay. Have you planned any courses more than two terms in advance? Yes, you said that, my fault. Have you planned all of your courses yourself, or do you use, like, the course planner to do it?

Ruby: I planned that myself. 

Rafael: Right, so you don't use the course planner at all?

Ruby: I don't use the document. I have a look at my course requirements, but not the document that they give you. 

Rafael: Right, would you say the documents are not accurate? 

Ruby: No, I think the document's accurate. I think it's. It just wasn't applicable to me because I switched into PPE, so I had credits from other things. 

Rafael: Right, okay. Would you like to, would you like to see a system where previous participants of a course can leave in note a summary of the course? So, like Ed Stem sort of except, you know, before you take the course. 

Ruby: Say that again, sorry. 

Rafael: So, you know, Ed Stem, right? 

Ruby: Yeah.

Rafael: Would you like, you know, like a forum system like that for every single course or most courses that you take where you could interact with past students or tutors of the course, or you can ask questions as to what it’s going to be about and stuff like that. 

Ruby: That'd be cool, although I think the ECP does give you that. But that would be cool and would be nice to actually hear from people who have previously taken it. 

Rafael: Yeah, right. Would you personally share short opinions on it? Like, do you think you would be an active participant helping students? 

Ruby: Well, probably not unless there was someone who I knew that asked me. 

Rafael: Right. Okay. Um, Would you prefer a system where course staff are present in the forums, or not present in the forum? So would you rather talk to students or staff, basically, or a bit of both? 

Ruby: Only students. 

Rafael: Okay, not even a bit of staff?

Ruby: A bit of both, but, like, I'd like to talk past students and their experiences with courses. 

Rafael: Yeah, okay. And what about the course positivity? So like at the end of the semester, you know, you get a feedback form. Would it be helpful if you saw how many people gave positive feedback? So, you know, if 70% of people like this? 

Ruby: No, I don't think so, because people usually do those forums in order to give negative feedback. 

Rafael: Right. Okay. So you think it's just, like, flawed?

Ruby: I think it's slightly. I think it's good that the course coordinators get that, to see what students are saying, but I think overall, people usually use those forms when they're a bit annoyed, but some of that happens. So I think that it would fit more and would actually accurately reflect how people felt about the course. 

Rafael: Okay. Thank you for your time.
