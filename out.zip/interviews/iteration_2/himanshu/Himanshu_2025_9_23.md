### Value Propositions Interview 3
*link to interview can be found [here](https://uq.sharepoint.com/:u:/t/Section_7560_62502/EcRbrEucjKpJgO0XbNxrgpwBqHkkEMPpSgIKCZOBhpAD_w)*
Himanshu:
*Hey, my name is Himanshu. I'm currently studying bachelor of information technology. So tell me about yourself, and can I record this interview?*

Muhammed:
>Yeah, you can record this interview. My name is Muhammed. I am a last year university student at UQ doing a bachelor of arts. 

Himanshu:
*So Have you ever planned your course for the upcoming Two terms?*

Muhammed:
>It's my last term, but I usually do plan my courses. I didn't do that initially, but I did it. I started doing it with the help of an academic adviser. 

Himanshu:
*So, do you worry that planning too far in advance isn't useful?*

Muhammed:
>I don't think it's not useful. If anything, it's Depends, if it's useful neutral, but it allows you to be flexible down the line. 

Himanshu:
*So in the past, when you're planning in advance, how likely do you think your preferences will change over time, like, which will change your plan?*

Muhammed:
>Do you mean how would I change my plan according to my preference system? Okay? Depends, what you do. 

Muhammed:
>It depends, um. If I think a subject is worth exploring, I will take it if I think that I don't want to do a course for a specific reason. For example, some courses, you know, every course has 7 GPA, right? But The way they're graded is very different. Some courses would give you like so many hurdles. You know, you'll have to do an assignment every week for a substantial amount of grades you know, so I take stuff like that into consideration. 
Um. I will stick into consideration my electives a lot like I really like to think of my electives. But in regards to preferences, not much But I am pretty flexible, so you said, you're doing a bachelor of 

Himanshu:
*Yeah, I am doing bachelor of information technology.* 

Muhammed:
>Information technology, I'm doing a bachelor rights. So I have a lot of flexibility. 

Himanshu:
*So, have you planned any course more than two terms in advance?*

Muhammed:
> Yes? Yes, I did. 

Himanshu:
*Have you planned all your courses yourself or relied on UQ adviser or course planner?*

Muhammed:
>I Initially chose the subjects myself, or I, they got recommended to me by someone. But I think it's very useful to speak to an adviser because programmes change so a lot of the courses I'm doing now, if I try and go find them on a course profile or go to a bachelor of Arts. And just try and find my major or my minors. They're all different. So I think that planning them is speaking to an academic adviser is very important. 

Himanshu:
*Thank you for your time.*

Muhammed:
>Thank you.
