### MVP Interview 1
Himanshu:
*Hey, my name is himanshu. I'm currently doing bachelor of information technology. What is your name and can I record this interview?*

Louis:
>Yeah, my name is Louis. And yeah, you can record me. 

Himanshu:
*Does our solutions show all the relevant information for your course?*

Louis:
>Yeah, I think it's relevant everything yeah. 

Himanshu:
*And we also add a comment section for our prototype. It will show like for the students already completed the course. It will give you feedback to how the course is from students.So do you, like the comments section being listed for each course next to its information.* 

Louis:
>Uh, yeah, yeah, I think that would be great. Cause sometimes you just have no real idea of what is your causes? So it's a really good idea. 

Himanshu:
*Uh, did you want any other links for each course. Like showing your course. And then next to it show link to your timetables or other things like your friend timetable or their courses.* 

Louis:
>Oh, yeah, that's maybe a good to have like to show your friend's timetable. That's so you just you don't have to like text them every time. So yeah, it's maybe good, yeah.

Himanshu:
*Thank you very much for your time.*

Louis:
>Thank you. 
