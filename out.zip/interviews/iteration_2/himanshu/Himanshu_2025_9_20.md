## Value Propositions Interview 1
*Interview can be found [here](https://uq.sharepoint.com/:u:/t/Section_7560_62502/EQ7ekq4Ik7RAtnQiijYkw9sBxMomq5jf8AYlTf4WOVtkug)

Himanshu:
*Hi my name is Himanshu I'm currently studying  bachelor of information technology. Tell me about yourself and can I record this interview.*

Tom:
>Hello, my name is Tom Andrew Mamuyac. I currently have a bachelors of biotechnology and Yes. 

Himanshu:
So Did you try to take  courses with your friends where it is possible? 

Tom:
>So with my experience, I actually took two gap years before going to uni. So that means that I'm already, two years behind with my high school friends, which means I'm basically on my own. So in that context, I cannot take a course with my friends, which means, well yeah, which means I am on my own. 

Tom:
>So If I did Not take my two gap years, then. Yes, I would have taken a course. My friends but I'm having a very good experience with the UQ so far I have already made twenty new friends or so, which I've made over a couple first few weeks so, technically Yes, I am taking a course with my friends for that first question. 

Himanshu:
So is this a significant factor in choosing for your course? Or would you say it's something that you try to do after selecting courses? Because you are just making your friends or* 

Tom:
>I'd say it's always It's it's in my nature to just try to experience something new, because it's It's, it's nice to well at first like I'm not saying like my my old friends are boring. I'm just saying that it's its 

Himanshu:
*Its always nice to meet new people.*

Tom:
>Yes, it's, it's always nice for in a friend group to always grow as people like as individuals, so that we aren't always stuck with the same perpetual cycle of just being with ourselves. But yeah, so it is a significant fact. Factor for choosing my course because I could enjoy the course more. 

Tom:
>And obviously that would drive me forward and you could also have the friendly rival with your friends. Of course, like 

Himanshu:
*It also motivate you to do more Study.* 

Tom:
>Yes, and it's beneficial for the school as well, because you'll end up having more students that are end up with high scores. So, yes, that's my answer for the second question. 

Himanshu:
*So do you know the SI-net has a built-in way to share your timetables with your friends and classmates?* 

Tom:
>I kind of did, I use SI-net to just plan the timetables for myself, and that was before school started. So if I was say in second semester right now, I would of course share my timetable with my friends through SI-net. 

Himanshu:
*Okay,is this a system that you you have often use. If you did know about it and would you say this is because it's useful for planning with your friends to for your classes or other things?* 

Tom:
>It is, the system exists already, so why not use it like this school already provides you with all the tools necessary for you to succeed. Then succeed. 

Himanshu:
*so, the last question, do you think it would be more beneficial? If there was a way you could better collaborate with prior selecting a course or do you already confer with friends prior to selecting course?* 

Tom:
> Depending on the situation if it was a situation where is just by myself, then, of course,I just choose the course by myself or the next step for that would be to confer with my family. And after I have conferd with my family, I could confer my friends. So it's three step Level or three level step process or whatever you would call it, but, yes, it is very beneficial. 

Himanshu:
*So it will be good if you have a separate website for planning.* 

Tom:
>Yeah, yeah, opinions matter to me of course. So, yes, any kind of suggestions or any kind of opinion would would greatly help 

Himanshu:
*Thank you for time.* 

Tom:
>no problem, have a good day 
