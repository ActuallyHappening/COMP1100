### MVP Interview 2
*link to interiew can be found [here](https://uq.sharepoint.com/:u:/t/Section_7560_62502/ERiwTRPr1khJqSN4e_mFdtsBzWzqnQt2g0pnJup-lub86w)*
Himanshu:
*Hey, my name is Himanshu. I am currently studying Bachelor of information technology.Tell me about yourself and can I record this Interview?*

Hudson:
>Yes, you can record this. My name's Hudson. I'm a first year studying psychology. 

Himanshu:
*So would you feel it useful to comment on courses for future in the solution that I just show you.* 

Hudson:
>Yes, that would definitely be useful. Sometimes, it's nice to have a student perspective on what the course is like, as opposed to what the uni is just telling you just like a much more authentic way to figure out what the course is. 

Himanshu:
*Would you like a badge for users based on if they are a tutor or lecturer or students or* 

Hudson:
>Ah, yes, it would definitely be useful to have a badge. You can see who's commenting on, So then you can see what perspective they're coming from, so you can look through or perhaps filter through, I want to see what tutors thinks, I want to see what students think or Whatever. 

Himanshu:
*Uh, do you also want all people who gave a review to be verified UQ students?* 

Hudson:
>Ah, yes, it would definitely be useful to see if they're verified or not. I'd definitely be looking for those people more, then, perhaps, just random, like random people who were just trying to write things in the course. 

Himanshu:
*For what if, like a random people just verified, and then comment something.* 

Hudson:
>Yeah, exactly, you could realise or even if you were the moderator you could feel throughout the fake ones and only use the verified ones. 

Himanshu:
*Yeah, okay, so would you like a beneficial for developing a new website? This, if you have any things you want to add to it or any, like things can you give a feedback on that?.*

Hudson:
>If I was developing it, you could perhaps some, I mean, obviously I haven't seen the Fuller thing and full, but you could have like the comments thing on the side as you're growing through. And perhaps you could say, have a different section where people will comment on the difficulty of it or they comment on, you know, whether they liked a specific tutor or so you can really filter through and see what information applies to you. 

Himanshu:
*Thank you very much for your time.* 

Hudson:
>No worries, thank you. 
