
### Value Propositions Interview 2
*link to the interview can be found [here](https://uq.sharepoint.com/:u:/t/Section_7560_62502/EQ7ekq4Ik7RAtnQiijYkw9sBxMomq5jf8AYlTf4WOVtkug)
Himanshu:
*Hello, my name is Himanshu. I'm currently studying bachelor of information technology. So can you tell me bit about yourself? 
And can I record this interview?*

Chloe:
>Sure, uh, my name's Chloe. I'm 21 years old and I, yes, you can you've got my consent to record this

Himanshu:
*Are you currently studying at UQ* 

Chloe:
>Yeah, yes, I do currently study at UQ. I study law and arts. 

Himanshu:
*Would you like to see a system where previous participants Of a course, can leave a note of a summary of the course or their opinions regarding the course.*

Chloe:
>Uh, yes, that would be helpful, especially for electives. Um, well, for electives, like we've only got a certain number of them in your course, so you would want to choose wisely, especially for law, because that can depend on like the practise area, you might go into.

Himanshu:
* would you like read short opinions Of a course, you were thinking of taking from the past students.*

Chloe:
>Um yeah, short opinions on like the course coordinator and that would be helpful just to sort of know what you're getting into. 

Himanshu:
*And would you like a system similar to  edsteam to like, prior to choosing a courses as to understand what actually happens in a course.*

Chloe:
>Uh yeah, I feel like it would be good to get a students perspective as to what happens like, obviously you've got the course profile, but you might need further information about like assessment types, some courses vary and like how they assess you, so that would be helpful. 

Himanshu:
*And What do you participate in a system where you aid Other students like the newcomers or other student that need helps with the course?.*

Chloe:
>Um, I'm that one sort of hard. Because I'm not sure if I personally have the capacity to help other people with a course, but I think most people probably would be open to that in some capacity. 

Himanshu:
*NO, it just like leaving comments.* 

Chloe:
>Oh, leaving comments. Oh, yes, sure that would be easy to do. 

Himanshu:
*And what do you prefer, a system where course staff are present in the forms, or they're absent in the forms?* 

Chloe:
>I think it would be better for openness to have the course staff absent from the forums, obviously you would have to regulate what is being said. So it's not just respectful against them, but I think students are more likely to be open and honest if they're not present. 

Himanshu:
*Thank you very much for your time.* 

Chloe:
>No worries, have a good day. 
