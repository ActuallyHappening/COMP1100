Himanshu: * hey, what is your name and what course are you doing can i record this interview?* 

siddhant: *my name is siddhant, yeah you can record this conversation.*

Himanshu: *Did you face any difficulties when you were choosing which courses to enroll in?*

Siddhant: *Yeah . The process was a bit confusing than I expected and I wasn’t always sure if the subjects I was picking were actually the right ones for my degree.*

Himanshu: *So overall, was the process of choosing courses for your degree difficult?*

Siddhant: *Yeah, it was, even though there are information available on courses and prerequisties but as i say earlier , I was figuring things out on my own and there is a lot of courses to choose from and they have various prerequisites, so yeah it was difficult for me.*

Himanshu: *would you find it beneficial to have a more seamless system to apply for courses?*

siddhant: *the current one is quite good , but I think it should add some new features like, when you click on a course it will show all things related to it like prerequisites and all the other information.*

Himanshu: *So, how do you keep track of your assignments due date, lectures do you use the course planner?*

siddhant: *usually I use the calender in my phone like, I put all the assignment due date and lectures in it to keep track of all of them. I don't usually use the course planner*

himanshu:*how important do you consider completing prerequisites priror to enrolling in a course?*

siddhant: * i think it is very important to complete the prerequisites before you enroll in a course, because it's give an idea what are you gonna be study in that course and you can understand things more easly if you have some prior knowledge.*

himanshu: *do you think that SI-net should ban enrolling in course with comopleting its prerequisite?*

siddhant: * It should not completely ban the the enrollment, I think it should show some notification because, if someone still want to do the course after knowing that there are prerequisites and stuff they should be able to enroll in.*

himanshu:*ok, thank you very much.*