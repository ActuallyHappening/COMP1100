Himanshu:
 hey, my name is Himanshu. I am currently studying bachelor information technology. Can you tell me about yourself.

Zara:
 I am Zara, I am doing my honours in ancient history.

Himanshu:
 So let's start with questions. Have you ever regretted taking a particular course sooner or a result of feeling unprepared or for credit reasons? 

Zara:
 I don't think so. No. 

Himanshu:
 Can you elaborate aabout it?

Zara:
 Um, no  I don't think i have experienced that.

Himanshu:
 how important do you think completing the prerequisites of a course is? 

Zara:
 Um, I think a lot of the times prerequisties are important  or at least they give you an idea of what's expected, even if they're not like a required prerequisite

Himanshu:
 Do you have any experience choosing  a course without doing its prerequisite?

Zara:
 Oh yeah. I've done courses where I've done something similar to the prerequisite course and been fine, because I have did something similar, yeah. 

himanshu:
 do you find it hard?

Zara:
 I in the most cases, I found it okay because I knew what to expect.

himanshu:
 do you have a future plan for you degree? 

Zara:
 Um, I'm just finishing my honours thesis right now. 

Himanshu:
 do you use a study planner? 

Zara:
 Yes, I use a study planner. 

Himanshu:
 do you find it difficult or easy to find the course that you wanted to do ? 

Zara:
 Um, I find it pretty easy because there aren't an incredible amount of course options for my major so, it's pretty specific like yeah 

himanshu:
Thank you for your time.
zara:
yeah ok, thanks