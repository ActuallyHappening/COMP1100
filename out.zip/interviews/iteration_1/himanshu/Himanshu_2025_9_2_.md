Himanshu: *Hello, my name is himanshu. I am studying bachelor of information technology. Can I record our conversation?, and tell me something about yourself.*

Hudson: *Hello, my name is Hudson. I am studying psychology here at the university, Queensland and I like playing basketball.*

Himanshu: *So How do you decide which course to enroll in?* 

Hudson: *How do I decide which course I was gonna do just through talking to different people and what sort of books I was interested in, I was always interested in psychology book. So I figured I would Ah study psychology.* 

Himanshu: *do you use a course planner to decide course and  specific electives?* 

Hudson: *Yeah, so I use a course planner to look to all of my electives that I was gonna pick. Um, and it really broke them all down so I could see what content I was gonna be learning and what was gonna best apply to my course.*

Himanshu: *So, do you find it easy to use course planner?*

Hudson: *Ah, yeah, it was relatively all easy and straightforward, gave me some instructions on the website, and it all displayed the information nicely and easy.* 

Himanshu: *Do you have any features that you want to add to course planner?*

Hudson: *Not, I can't really think of anything off the top of my head that particularly stuck out as it was a long time ago, um, maybe maybe something to sort of say like, if you do this subject here, this means you can't do the subject in the future because it's going to clash.* 

Himanshu: *So how do you find the integration between the  numerous websites that UQ uses to display and utilise your information regarding courses?*

Hudson: *Yeah, the integration between the courses and the information. Yeah, I think it's really good. It all shows it very clearly.*

Himanshu: *Is there any difficulties that you have faced? Like choosing your course to enroll in.*

Hudson: *It can be quite difficult seeing what courses I can actually like which I'm allowed to study in my course when you go into select them at can't it just has the list of every single course available and you've gotta figure out how to narrow it down yourself. So it would be useful to be able to say these are the psychology courses you can pick from, and it's just in one menu.* 

Himanshu: *Thank you, thank you for time.* 

Hudson:*No worries, thank you.*
