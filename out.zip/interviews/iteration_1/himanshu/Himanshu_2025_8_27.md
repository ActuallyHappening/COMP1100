himanshu: Hey, my name is Himanshu. I am currently studying bachelor information technology. Can I record this conversation.

Yizhou Wang: Yes, of course. 

Himanshu: what is your name and which course are you studying?

Yizhou Wang: My name is Yizhou Wang and I am studying bachelor of Computer science. 

Himanshu: would you find it beneficial to have a more seamless system to apply for course?

Yizhou Wang: For watch course. Can you explain about this question? 

Himanshu: yeah,The question is like when you are applying for your course, you have to go through a lot of things like prerequisties, so you can apply for your specific course you want to enrol in, so do you find it difficult or easy and do you want to have a more seamless system To apply easily for that? 

Yizhou Wang: I find it quite troublesome, too like I find my find the course I need, so I have to open my uh, like the information of my program and look through the course list that I need to take and then a select a corresponding course profile at mySI-net, I think that process kind of a troublesome and I think a better designed UI,  could solve this problem by like displaying your program information and then your course information at the same time.

Himanshu: So how would you find the integration between the numerous websites that you have, such as mysi-net, timetable planner,that UQ uses to display and utilize information regarding courses?

Yizhou Wang: The overall usage experience of a timetable is pretty good but ah, there could be some like improvement to apply on this by try to like, uh, potentia lly allocate both like, course block and timetable like for better planning of your time segements, I haven't tried that like personal timetable like, don't much I know its displaying like all of course block and some of the assignments due date but I am not keen on using that I just keep track of my course and like timelines myself or like course by course.

Himanshu: So you don't usualy use the planner and just write down on paper or something like spreadsheet?

Yizhou Wang: No, I use the timetable, but I don't like relay too much on it for like, the course times the second times and for assignment due dates, I just keep tracking all of them  myself like what announcement and assignments specification. Yeah 

Himanshu: thank you for your time.