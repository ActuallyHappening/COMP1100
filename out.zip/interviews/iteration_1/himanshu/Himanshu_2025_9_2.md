Himanshu: *Hey, my name is Himanshu. I'm currently studying bachelor of information technology. So can I, record our conversation and what is your name.* 

Mujahid: *yeah, so my name is Mujahid and yeah, I am ok with this interview.* 

Himanshu: *So, let's continue with our questions. So Would you ever consider doing a course without having completed its associated prerequisties?* 

Mujahid: *Uh, actually, during my first semester. Yes, I did. Take one without any prerequisite, which is 2310 computer system and principle.But about week 5 is getting harder and I dropped the course, so I think it's very important to do the prerequisite before you enrol in any courses.*

Himanshu: *So how do you come to choose that course without doing its prerequisite?* 

Mujahid: *Mainly because I found the subject is interesting because it teaches you like low level programming C language and I thought I could handle it, but eventually it's very difficult. 

Himanshu:*So, how did you find about that course, did a friend told it to you or ?*

Mujahid: *Actually it came from my seniors. Uh, he told me that I can take it. that I'm able to do it, but eventually yeah, it's getting harder.*

Himanshu: *How important do you think completing prerequisites prior to enrolling in a course?*

Mujahid: *Personally, I think it is very important to do prerequisites, because as I said earlier, if you're just going to course without knowing what are the background that you need, then end up in the long run, you will become stressful to do the subjects here.*

Himanshu: *Do you wish mySI-net would ban you for enrolling in a course without having completed its associated prerequisites?*

Mujahid: *I think SI-net should do that should enforce that. Because if students  just enrolled without knowing what they will be facing, it is very problematic for them to continue the course in the future. So I think Si-net should really enforced prerequistes before enroll in any course, yeah.

Himanshu: *Thank you for your time*
Mujahid: *Alright, Thank you* 
