Himanshu: *Hi,my name  is Himanshu. I am currently studying Bachelor of information technology. Can I record our conversation and tell me about yourself.*

Adam: *Yeah,you can record this, my named is Adam. I am studying bachelor of science majoring in math.*

Himanshu:* How do you choose your electives for your degree?*

Adam: *well, Doing a bachelor of science, I have the option to do a lot of electives and at the start of my course, I was actually doing science and arts, so a lot of my electives have been taught up in language like Chinese and Japanese and all the other electives that I have had with exception of like one physics cause have just all been math, because I want to specialise, and I want to um, be able to get most out of degree so most of my electives are just math* 

Himanshu: *Would you consider doing a larger selection of your course if you know what was on offer?*

Adam : *Maybe I think um, if I would do it all over again, I would probably choose a different structure to my degree. I do a joint degree of bachelors that are more linked for example, math physics may be math engineering, science, math something like that, but just as a bachelor of science, no I think I like to specialise. I like to um, yeah i would specalize.* 

Himanshu: *So do you usually use course planner for planning your things like assessment due date, or do you use something like excel sheet?*

Adam: *Hmm, for planning out my uni like semester timetable. I usually just use the calender on my phone like I Put in the assessment due dates and when the exams are all that kind of stuff. So now I don't actually don't use the uni resources for planning at all I just used it to allocate my courses and that's it.* 

Himanshu:*And finl question, how do you think about the integration about the numerous websites that UQ uses to display and utilising information regarding courses?*

Adam: *I sometimes think it's a little bit convoluted, I would really enjoy a my UQ app like I wouldn't have to go on Google everytime and I think I'd really enjoy, that to be information availabe  On the portal, like on the my UQ, because when I have to do research my degree, I have to go through the websites it's a very long process like, I have to figure out what courses I have to take the requirements are and if I'm not doing that, I have to actually like, email someone, talk to someone , I definitely appreciate resources through the portal. I think a student portal.*

himanshu: *Thank you very much.* 

Adam: *thank you* 
