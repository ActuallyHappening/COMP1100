Hiamnshu: Hey, my name is Himanshu I am currently studying bachelor of information technology. Can I record our  conversation?

Yuki: Yes, of course

Himanshu: so which course are you doing. 

Yuki: I'm doing engineering and business double major. 

Himanshu: Do you have a plan for what course you were going to do after this? 

Yuki: Um, yeah, I do 

Himanshu: do you use a course planner ? 

Yuki: I make one myself, so it's easier to read. 

Himanshu: Can you elaborate about it , like do you use a excel sheet or write it down on paper?

Yuki: Um, I prefer using a calendar like a paper calendar, because I can see it all better. I hang it in front of my desk, and whenever the assignment is due or something like that, I've write it before so that when it comes that month and I flip it open I can see everything.

Himanshu: Do you ever make mistake like choosing the wrong course or things like that?

Yuki: No, not actually, because this is only my second semester at UQ and  nothing happened like that before, but I hope it would not happened but yeah.

Himanshu: Last question, would you find it beneficial to have a more seamless system to apply for course?

Yuki: I personally, don't take any problem with the system that we have now to apply for course I think it's okay, um, I just wish we might be able to see like the course description mixed with the course we are trying to apply for so like when you click it, you know what it is, and you can be like really sure like what is it.

Himanshu: Thank you for time.