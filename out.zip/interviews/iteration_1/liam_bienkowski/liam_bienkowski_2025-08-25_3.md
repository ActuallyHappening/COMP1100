### Interview 3
*Interview can be found [here](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=/teams/Section_7560_62502/Shared%20Documents/Mon_9am_Team_10/liam_bienkowski_audio_recordings/iteration_1/liam_bienkowski_2025-08-25_3.mp3).*

Liam: *OK, Felix, are you able to be recorded? *

Felix: 
>Willing and consenting. 

Liam: *Okay, so tell me about, like, your experience with enrolling into courses at UQ. Did you have any difficulties?* 

Felix: 
>Um I mean, I think the whole, like, mySI net thing is pretty, like complicated and I don't know, I feel like they could totally like, cut down and one or two of those websites and just make it all simple. Like, I do remember thinking, like, oh, yeah, am I actually enrolled in this course, etc. 

Liam: *When you talk about cutting down on one of the two of those websites, what do you mean by that?*

Felix: 
>just simplifying, you need a one hub place to do it, like, I'm a bit too dumb to go navigating through all these things and you know, sometimes I've had some people who I know as well. They've enrolled in the wrong thing or they haven't enrolled because they've just like, you know, signed up to an Instagram page instead of something. 

Liam: *What do you mean, signing up to the wrong thing? What did that entail?* 

Felix: 
>As in, like, I know someone who was like, trying to sign up for, like, anatomy and they accidentally signed up for communism in practice. 

Liam: *How did that happen?* 

Felix: 
>It happened because it's just too cluttered. I need to cut down on all of this, this fluff that just makes it hard to navigate, and there's real world consequences. 

Liam: *So, where it was hard to navigate, Were you able to find, like, what courses you should have done beforehand or what courses you should be taking alongside your current course selection?* 

Felix: 
>No, that's actually a thing though. Like, I like, looked at my things and I said, I could only do them in semester two. But that's when I realised that it was actually semester two. You know, it's just a bit confusing, all this whole, like how you have to enter in search your thing. You know, you should be able to, like, enter your, like, student ID and it should tell you what you should be doing. And then if you've got any free things, you should just say that. You shouldn't have to like, sort of scroll through Wikipedia just to like, find a course. And also, like, this, like... Forgive me for my language, but the shit about, like, having like, to Google course profiles, bro. Like, I hate that. Like, I'm looking at the internet. I was looking at the 2021 version as well. Like, thank God they were the same. But having to do that, that's just so annoying. 

Liam: *Yeah, so, um... So, would it be true that then that you wanted to know, like, you wanted to have completed the prerequisites for your courses before you actually enrolled in them?* 

Felix: 
>Are you just trying to figure out, like, how like how cooked I didn't do it? 

Liam: *Oh, no, like, this is like a preference thing. Did you want to have your prerequisites known before you did your course? So you have completed them?* 

Felix: 
>For sure. Like, I only have, like electives in my fourth year, and I don't need to be like selecting random things, you know. It should auto fill it for me. It should tell me what I need to be doing. 

Liam: *Yeah, and then one final question. Um. About how long would you say you were spent doing, like doing this section of your courses and how much extra time do you think was dedicated to just trying to figure stuff out?* 

Felix: 
>About six, seven minutes for trying to like, pick the course and about six, seven hours, just trying to figure out my life, get my shit together, etc. 

Liam: *Like, why did it take so long?* 

Felix: 
>There was a lot of shit to get together. But, in terms of the website, uh just because you have to like, like, just trying to like sign up to one class you have about ten tabs open, then you get timed out and stupid duo mobile and Bro, UQ needs rethink their technology. I'll say that. It's not very good. 

Liam: *Okay, well, thank you very much for your time.* 

Felix: 
>You're very welcome.