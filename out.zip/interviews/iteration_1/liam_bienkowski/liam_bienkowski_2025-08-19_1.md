### Interview 1
*Interview can be found [here](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=/teams/Section_7560_62502/Shared%20Documents/Mon_9am_Team_10/liam_bienkowski_audio_recordings/iteration_1/liam_bienkowski_2025-08-19_1.mp3).*

Liam: *Right, Alex you okay to have this into your recorded?* 

Alex: 
>Yes. 

Liam: *Okay, so the first question that I would like to ask you is, would you find it beneficial to have a more seamless system to apply for courses?* 

Alex: 
>Yeah. 

Liam: *Would you elaborate on why?* 

Alex: 
>Um. I mean, can I say how much I hate Duo? 

Liam: *That can be a part of it.*
 
Alex: 
>No, I'm gonna you're gonna just get me to start ranting on the blackboard site. I want to rehaul the blackboard side. Can you do- is that part of the assignment? 

Liam: *Sure.* 

Alex: 
>I want to- I'd rather you rehaul the blackboard side. My assign just got a terrible UI. Looks like it's made in the 2000s or the '90s or whatever. And like, oh, the UI for like selecting things is or like select enrolling in courses, it's like a default HML form. Am I going over time? 

Liam: *No*

Alex: 
>Yeah, it looks like a default HTML form. Okay, And it's also just like, it feels like it's really technical when it should be just like a very nice, clean UI/UX experience and it shouldn't feel like you're going into the archives of UQ to try to enrol in your courses. But, like, besides that, the searching it up as, like, did, I presume it's some API that it hits. Yeah, it works fine, I guess. I don't- I've only done it twice, so I don't really remember the experience too fondly. I just remembered that the UI is really old and I hate using blackboard, because the UX is terrible. Is that? Yeah, that? 

Liam: *Yep. I just like follow question. How would you find the integration between the numerous websites that UQ uses to display and utilise information regarding courses?* 

Alex: 
>Do not get me started! Why do you need three separate sites that I have to- four separate sites: Gradebook, Blackboard, Dashboard, my timetable, My-SI.net- You don't need five separate sites, and I have to authenticate myself, like, to look at my timetable, like, um. Oh, my God, no. Just, like, it needs… Okay, obviously, like, when you try and standardise something, like, if you have five standards and you want to make a new standard or something, you have six standards. Like, um, but, like, oh my, I know Blackboard's the primary thing you use, and like, I rarely use dashboard, but, like, the, timetable is also sort of on the dashboard, but, like, if you're using, oh, my God, and Blackboard has, like, two different versions and you have to go to GradeScope, just, it's very annoying having, like, five different things. I want them all integrated in one spot. 

Liam: *Yes, like, when you're choosing courses then at the start of the term, like, how long do you think you take to find out prerequisites, and then choose your courses accordingly?* 

Alex: 
>Oh, my God yes, this is another site, actually, which is the site where you get all the information from, like the documentation, whatever they call it. And then there's also the course planners and whatever. But, oh, yes, Oh, my God, you just reminded me, like, when I'm looking at like, my course and like looking for each of the subjects, I wish you give us those like a little thing where I could see the prerequisites, like an extendible thing. Instead of having to click on it, go into a seventh site, is it, a seventh different site, which also looks like it was made in the 2000s, and the prerequisites in this tiny little box on the side in this little box. And so I have to open like a million different tabs and see all the prerequisites, all the subjects to pick the subjects I want to do. Yes, I agree. That is super in a way. I've been thinking about this. Like, I want you literally, I have a lot of thoughts about this. This is great. Okay, yeah. 

Liam: *So, like, yeah, so, at the start of the semester, how long do you think it would take you in terms of minutes?* 

Alex: 
>Oh, I spend like, like when I'm, like researching my course to make sure I get the right subjects for the prerequisites, I can spend over, like half an hour an hour, because it's so cumbersome, just, like, traveling, like navigating all of this- navigating this UI and over to different sites and like, keeping track of everything, yeah. 

Liam: *I think that's all we have time for. Thank you very much.* 

Alex: 
>Well, wait, one more thing, actually. And also how you have to go to a different page to look at your major option as well. That also, I don't like that. And all the little accordions, there's got to be a better way to, like display it. Anyways, yeah. 

Liam: *Thank you for your time.* 