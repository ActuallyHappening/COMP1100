### Interview 6:
*Interview can be found [here](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=/teams/Section_7560_62502/Shared%20Documents/Mon_9am_Team_10/liam_bienkowski_audio_recordings/iteration_1/liam_bienkowski_2025-08-27_6.mp3).*

Liam: *OK, so James, are you okay to be recorded?* 

James: 
>Ah, yes, I am. 

Liam: *All right, so the first question is, how has your experience at UQ been so far in terms of enrolling into courses? Have you experienced any difficulties?* 

James: 
>I found it pretty confusing at the start, like, as in first semester, trying to find my courses, find out what I need to do for my majors. I didn't find they explained it very well, so I found it quite, quite difficult to manage my classes for having, say, tutorials before the lectures or after I wasn't sure on how it all worked, had to ask a lot of different people, and I didn't find UQ explained it very clearly. 

Liam: *Did that lead you to make any mistakes in your enrolment?* 

James: 
>Yeah, it just made me have poor time timing for my classes. So my first semester, I was all over the shop for my week, but then second semester, I've put them all in correctly, because I actually understand it now. 

Liam: *Yeah. And when it comes to finding the classes themselves, like, the actual courses you want to enrol in, how did you find that getting through your first few semesters?* 

James: 
>Oh, I found that was all right because they provided the big big sheet that filled. What do you call it? You know, with all the courses on what to do, and because of my subjects that I'm doing, it was very, I can just choose those exact courses, I don't have to plan ahead, but I've heard from other people that it was quite annoying. 

Liam: *Yeah, um. So.. when it comes to actually. So you don't have any electives, correct?* 

James: 
>No, no, I just have all core courses. So that's what I mean. I could just choose the exact ones they said to. 

Liam: *Yeah. And so, how did you find navigating between all the different UQ pages to enrol into your courses?* 

James: 
>Oh, it was absolutely terrible. Literally the worst system I've ever ever used. I hated every second of it. 

Liam: *Would you be able to elaborate on why?* 

James: 
>Um, it's just like a terrible interface. Everything takes years to load. It crashes half the time, you have to log in every two seconds, you have to do your authenticator every second time you log in. It's just an absolute pain. 


Liam: *And so finally, when it comes to, like, finding prerequisites and codependent courses, how did you find that process?* 

James: 
>What do you mean? 

Liam: *So, like, say. um one course might be, you might have had to complete another course before.* 

James: 
>Oh, course I got you. Um, Look, I mean, on the UQ site, they did have, you got to do these courses to do these majors, but it was an absolute pain to find and navigate through. And I wish there was just like a clear cut way just to go,You do these courses, you get this major. Simple as that. 

Liam: *Alright, well, thank you very much for your time.* 

James: 
>Yeah, no worries.