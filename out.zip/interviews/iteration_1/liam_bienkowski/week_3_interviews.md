**Interviews done on preliminary questions.**
### Closed Question:
Liam: *Now, Ben, when you were applying for your course, did you find the process of selecting like the order in which you're going to do your courses to be more difficult than you imagined?*

Ben: 
>No, I found it to be what I expected. You find the course codes from your course guides and enter them in. It's all quite straightforward. 

Liam: *And how about prerequisites; were prerequisites more difficult than you imagined, trying to work around them?* 

Ben: 
>In terms of meeting them, no, at least for the first year, it was fine for me. It'd make a more difficult later, I don't know, but the release clearly stated, so I'd say no, it was not difficult. 

Liam: *Yeah, and just coming back to that, would you say that, like, the process of navigating all the sites was more difficult than you imagined, or was it easier than you thought it was going to be coming into uni to find all your details?*

Ben: 
>I'd say probably a bit difficult, manly because my SI-Net are the layout of that compared to the course guides on the public website is very different and very jarring. But once you get the hang of it, it's not too bad as long as you know where to look. 
Liam: Thank you very much.


### Open Question:
Liam: *So, Matthew, tell me about any difficulties that you might have had when doing like to the course planning for your degree.*

Matthew: 
>Um, figuring out which course is to do and which semester and like, some course are in the offered one semester a year or sometimes even one every second year to figuring out when to do what. 

Liam: *Yeah, just like come into like also like figuring out your prerequisites and stuff like that for those courses?*

Matthew: 
>Yes, exactly, yeah. That's also, yeah, that's important, yes. 

Liam: *Yeah, and it's like, how difficult would you say that was going through, especially at the end of last year, figuring out how to enrol in your courses this year?*

Matthew: 
>Well, I haven't exactly fully you got a plan yet, because I don't exactly know course me do, so I still in the process, but I think not too difficult once you actually know what you want to do, but when you have to balance the two together, it's a part of. 

Liam: *Okay. Thanks.*
