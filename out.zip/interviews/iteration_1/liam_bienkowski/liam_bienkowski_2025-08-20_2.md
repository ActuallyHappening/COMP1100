### Interview 2:
*Interview can be found [here](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=/teams/Section_7560_62502/Shared%20Documents/Mon_9am_Team_10/liam_bienkowski_audio_recordings/iteration_1/liam_bienkowski_2025-08-20_2.mp3).*

Liam: *Hi Jono, are you okay to have this interview recorded?* 

Jono: 
>Yeah, I'm all good. 

Liam: *Okay, so. um can you start by just like talking about have you encountered any difficulties when enrolling into any of your courses for this semester at UQ?* 

Jono: 
>It- It took a little while for the courses to actually update on my thing. And when timetables came out to allocate, my courses weren't actually enrolled, so I couldn't preference my timetable in time. But like in terms of actually enrolling, not that much struggle. Yeah. 

Liam: *How did you find navigating like, prerequisites and similar through the different UQ course sites?* 

Jono: 
>Oh, um for me, for my degree, it's pretty straightforward, because there's not too many prerequisites. But, like, the course profiles are a bit annoying to go through and like, have to look individually each course to find all the prerequisites for it. But, like, I know how to do it. It's like it's very well, like very commonly known. Yeah. 

Liam: *How long do you reckon it took you to figure out what courses you wanted to enrol in each semester and look at the sites?* 

Jono: 
>A while. Like, it did take a while because you have to research each individual course profile of the courses you want. And, like, the courses aren't all just somewhere. Like, you have to individually research them. So. an estimate, like… I was a bit indecisive, but it did take me a good two weeks or so over the break, to actually dead set on which course. And that I could do. 

Liam: *Yeah… And so. this as well on that. When you went to actually enrol… like, did you want to have completed the prerequisites beforehand?*

Jono: 
>Yes. Yeah. I have got like a sort of plan for my degree. So I do know generally the prerequisites to do. So I was looking for them when I was searching through. 

Liam: *How hard was it for you to make your plan for your degree?* 

Jono: 
>Um, because I am preMed, there is a lot of stuff around that, so not too hard. But I imagine other degrees would be a bit harder if they didn't have that. Because that saved me. 

Liam: *Yeah, and one final question. With your electives, how do you choose what electives you want to do?* 

Jono: 
>Spinny wheel, no, um, like, for me, it's like a, it's mostly, like, easiest. Like, I normally go for what's enough and what won't cause me too much stress. Low contact hours. That's like ideal for me. That's like my main descriptors. 

Liam: *All right, thank you very much, Jono.* 

Jono: 
>That's all good.