### Interview 4:
*Interview can be found [here](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=/teams/Section_7560_62502/Shared%20Documents/Mon_9am_Team_10/liam_bienkowski_audio_recordings/iteration_1/liam_bienkowski_2025-08-26_4.mp3).*

Liam: *All right, so, Willem, are you okay with having yourself be recorded?* 

Willem: 
>Yes

Liam: *So. Willem, first, tell me about, like, how your experience has been so far at the University of Queensland in regards to enrolling into courses and any difficulties you might have had.* 

Willem: 
>Enrolling in the courses was pretty simple, the one single headache was PSYC1030 and being allowed to use the computer for that. But other than that, most of them have been pretty smooth. The only other thing I can really think of with not being told that you have to, like, for in-semester in-week assessments, you have to manually submit to get your changes form. But other than that, it's been pretty simple enrolling in courses. 

Liam: *Yeah, and so like, at the beginning of the semester, like, before the semester started, how did you find the process of, like, finding your courses and enrolling into them?* 

Willem: 
>The only thing that I kind of found difficult at any point was determining which ones I wanted to do. That's more because, like, not that many psych ones that I also was not doing as an elective as a core subject and or are the ones that didn’t really interest me. So, that, but, like, actually the ones I found, once I found the course that was interesting, it was not, it was really easy to enrol and do all that. 

Liam: *Yep. And so you have electives, correct?* 

Willem: 
>Yes. 

Liam: *So, if you. Like, how, what is the process that you use to choose what electives you want to do?* 

Willem: 
>Uh, first, for one of them, health 1000, it would suggested by the psychology department if you wanted to go into clinical psychology, which I do, uh, then the other l that I have this semester, ECON1310, it's an easy stats course. I'm doing it for easy marks. 

Liam: *And so if you were aware of all, if you had a greater knowledge of all the courses that the university offered, would you consider doing a larger, like array of electives?* 

Willem: 
>Uh. Probably not really. That's just because… the main subjects that are of interest to me are the psychology ones and I’m already doing all the psychology ones anyways as the core. Like, maybe I grab a bio one, but, like, generally, I, I only, I really struggle with finding courses I thought were going to be interesting in terms of electives, most of them were even grabbed because I thought they might have been useful, or they were going to be easy this semester. And I think it was like one I picked could it look good, it looked interesting, but other than that, like, it was a bit of struggle to find one that I found interesting. My area of interest is what with psychological studies, which I am already doing a lot of. 

Liam: *Yeah, and so when you enrolled into your courses, were you aware of the prerequisites or, like codependent courses that might run with your current course election?* 

Willem: 
>I- It was pretty easy when looking on just searched up the name in the course profile and course prerequisites or just checking all the requirements if that wasn't too hard. 

Liam: *Yep, and so overall, like, with your university experience so far, with courses, just, like, any other overarching- Were there any other overarching difficulties or has it been pretty smooth so far?* 

Willem: 
>It's being pretty smooth so far. 

Liam: *Right, well, thank you very much, Willem.*