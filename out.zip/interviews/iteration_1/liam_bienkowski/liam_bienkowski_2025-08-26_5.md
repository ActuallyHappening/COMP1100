### Interview 5:
*Interview can be found [here](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=/teams/Section_7560_62502/Shared%20Documents/Mon_9am_Team_10/liam_bienkowski_audio_recordings/iteration_1/liam_bienkowski_2025-08-26_5.mp3).*

Liam: *Eoin,  do you consent to having this interview recorded?* 

Eoin: 
>Yes. 

Liam: *So, first question I want to ask is, how is your experience been at UQ so far in regards to enrolling into courses and have you experienced any difficulties?* 

Eoin: 
>I was kind of confused at first what courses I was meant to do as part of my overarching degree and where to go. I did eventually sort of find it, but it was kind of hard to figure out that. Once I got there, though, I think, aside from some kind of dodgy UI and stuff on my SI net part, I think a lot of it wasn't too bad to sort of wrap my head around and figure out what to do. And there's always like the professors have been pretty helpful if I want to ask questions and sort of. 

Liam: *Yeah, so like, how has the experience been finding, like prerequisites and stuff for your courses?* 

Eoin: 
>Oh, bro, that whole prerequisite, the whole site just looks so… It's hard to read and kind of just terrible, I'm going to be honest. Yeah. 

Liam: *Because do you, when you are enrolling in courses, do you plan to have completed the pre-reqs before you do the course?* 

Eoin: 
>Yes, yes, I do. 

Liam: *Yeah. And so, like, how long do you think it takes you to enrol in courses each semester? And how much longer did you think it takes you based on the difficulties you've described?* 

Eoin: 
>Well, I think the fact that there's not really an easy sort of layout for what the prerequisites are, and the fact that you have to keep going into, if you see a prerequisite, you have to then click on that one to then find the prerequisites for that. I think I think a considerable section of the time is just me trying to figure out what I actually need to do to do the courses. So I think it could definitely be nicer, more streamlined, which would help save a lot of time. 

Liam: *Yeah. And so do you have electives in your course?* 

Eoin: 
>No. Like general electives? No general electives. Oh, I think I have one or two, but they have to go towards third year physics. So I don't really have electives. 

Liam: *Okay. Um. And just some final questions. When you are like going through all the sites, what do you reckon is the hardest part about the enrolment process?* 

Eoin: 
>Reading. When you click on the program and it has that whole information set, it is the most annoying thing to read in the history of anything ever, I'm going to be honest. And just generally. 

Liam: *Yeah. Like, are there any areas of, like, just the UQ courses space in general that you like or that you wish to be improved?* 

Eoin: 
>I really like the way, once I figured it out, I like the way that- so for my degree, I have like a sort of specialised thing, but it tells me what units, how many points I have to do from certain units. I really like the way that's laid out. I think that's quite nice. 

Liam: *Like the degree planner. PDF…?*

Eoin: 
>Oh, no. Oh my goodness. The my timetable, like, that stuff like so that- that can be really annoying to sort of work with sometimes. It's also very, very helpful, but it can be annoying to work with. But I mean more like when it it's like a plan that just tells me what I have to do for my degree. I don't really know what it's called, but it's like set course and program structure or something like, you know. Yeah. 

Liam: *Well, thank you very much, Eoin. Thank you for your time. Thank you very much.*